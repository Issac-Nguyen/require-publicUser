define([], function() {
	return {
		text: '<a href="views/defect.html">${name}</a>'
	}
})