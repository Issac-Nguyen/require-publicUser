define([], function() {
	return {
		text: '<a href="./views/imageDetail.html"> <img src="${dataURL}" width="50" height="50"/></a>'
	}
})