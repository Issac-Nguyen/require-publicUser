define(['./template-defect', './template-image'], function(templateDefect, templateImage) {
	return {
		templateDefect: templateDefect.text,
		templateImage: templateImage.text
	}
})