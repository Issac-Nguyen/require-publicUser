define(["kendo"], function(kendo){
   return {
       viewModel: kendo.observable({
           message: "This rocks!"  
       })
   } 
});